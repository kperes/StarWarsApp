package com.batista.kleyton.starwarsapp.Resources;

import java.util.List;

public class PersonagemResultado {

    public List<Personagem> results;

}
